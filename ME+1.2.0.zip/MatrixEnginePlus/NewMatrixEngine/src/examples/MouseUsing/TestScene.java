package examples.MouseUsing;

import engine.*;
import engine.widgets.*;
import org.jsfml.graphics.*;
import org.jsfml.window.event.*;

import java.io.IOException;

public class TestScene extends Scene {

    Texture texture = new Texture(); // создание новой текстуры
    GameObject object; // добавляем игровой объект


    public TestScene(RenderWindow window) throws IOException {
        // получаем изображение из папки с ресурсами
        texture.loadFromFile(Engine.getResource("block.jpg"));
        object = new GameObject(10, 10, texture); // создаём игровой объект
    }

    @Override
    public void onUpdate(RenderWindow window, Event event) {

        object.positionX = Mouse.getX();
        object.positionY = Mouse.getY();

        object.updatePosition(); // обновляем позицию
    }

    @Override
    public void onRender(RenderWindow window, Event event) {
        object.draw(window); // рисуем объект на экране
    }
}
