package examples.Button;

import engine.*;
import engine.widgets.*;
import org.jsfml.graphics.*;
import org.jsfml.window.event.*;

import java.io.IOException;

public class TestScene extends Scene {

    Theme theme;
    Font font;
    Button button;

    public TestScene(RenderWindow window) throws IOException {

        // создаём шрифт
        font = new Font();
        font.loadFromFile(Engine.getResource("roboto.ttf"));

        // создаем тему
        theme = new Theme(
                new Color(255, 255, 255),
                new Color(230, 230, 230),
                new Color(50, 50, 50),
                new Color(50, 50, 50),
                font,
                15
        );

        // создаем кнопку
        button = new Button(
                "Click me!",
                new Rect(100, 100, 300, 80),
                theme
        );

        // устанавливаем слушатель кнопке
        button.listener = new ButtonListener() {
            @Override
            public void listener(Button button) throws IOException {
                window.close();
            }
        };

    }


    @Override
    public void onRender(RenderWindow window, Event event) throws IOException {
        button.draw(window, event); // рисуем кнопку на экране
    }
}
