package engine;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Engine {
    public static Path getResource(String name) {
        StringBuilder path = new StringBuilder();
        String nativePath = System.getProperty("user.dir");
        String[] allDirs = nativePath.split("\\\\");
        List<String> stringList = new ArrayList<>();
        int count = allDirs.length;
        stringList.addAll(Arrays.asList(allDirs));
        stringList.remove(count - 1);
        stringList.add("Resources");
        stringList.add(name);

        for (String dir : stringList) {
            path.append(dir).append("\\");
        }

        return Paths.get(path.toString());
    }
}
