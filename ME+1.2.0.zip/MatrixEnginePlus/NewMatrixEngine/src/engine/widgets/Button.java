package engine.widgets;

import engine.Mouse;
import org.jsfml.graphics.*;
import org.jsfml.system.Vector2f;
import org.jsfml.window.event.Event;
import engine.Scene;


import java.io.IOException;

public class Button {


    public String text;
    public Rect rect;
    public Theme theme;
    public RectangleShape shape;
    public Color currentColor;
    public Color currentTextColor;
    public Text visualText;
    public ButtonListener listener;

    public Button(String text,
                  Rect rect, Theme theme) {
        this.text = text;
        this.rect = rect;
        this.theme = theme;
        this.shape = new RectangleShape(
                new Vector2f(rect.w, rect.h)
        );
        this.shape.setPosition(rect.x, rect.y);
        this.visualText = new Text(text, theme.font);
        this.visualText.setCharacterSize(theme.textSize);
    }



    public void draw(RenderWindow window, Event currEvent) throws IOException {
        FloatRect fr = visualText.getLocalBounds();

        float mx = engine.Mouse.getX();
        float my = engine.Mouse.getY();

        boolean isTouchX = (mx > rect.x && mx < rect.x + rect.w);
        boolean isTouchY = (my > rect.y && my < rect.y + rect.h);
        boolean isTouch = (isTouchX && isTouchY);

        if (isTouch) {
            currentColor = theme.hoverColor;
            currentTextColor = theme.hoverTextColor;

            if (currEvent != null) {

                if (currEvent.type == Event.Type.MOUSE_BUTTON_PRESSED) {
                    if (listener != null) {
                        listener.listener(this);
                    }
                }
            }

        } else {
            currentColor = theme.standartColor;
            currentTextColor = theme.standartTextColor;
        }

        visualText.setPosition(
                rect.x + rect.w / 2 - fr.width  / 2,
                (float) (rect.y + rect.h / 2 - fr.height / 1.25)
        );

        shape.setPosition(rect.x, rect.y);
        shape.setSize(new Vector2f(rect.w, rect.h));

        shape.setFillColor(currentColor);
        visualText.setColor(currentTextColor);
        if (window != null) {
            window.draw(shape);
            window.draw(visualText);
        }

    }
}
