package engine.widgets;

import java.io.IOException;

public interface ButtonListener {
    public default void listener(Button button) throws IOException {

    }
}
