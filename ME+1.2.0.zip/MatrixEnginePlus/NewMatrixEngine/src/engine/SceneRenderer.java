package engine;

import org.jsfml.graphics.RenderWindow;
import org.jsfml.window.event.Event;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SceneRenderer {

    public static List<Scene> scenes = new ArrayList<>();
    public static RenderWindow window;

    public static void render(Event currentEvent, RenderWindow window) throws IOException {
        for (Scene scene : scenes) {
            if (scene.isActive) {
                scene.onUpdate(window, currentEvent);
                window.clear(scene.background);
                scene.onRender(window, currentEvent);
                window.display();
            }
        }
    }

    public static void addScene(Scene scene) {
        scenes.add(scene);
    }

}
