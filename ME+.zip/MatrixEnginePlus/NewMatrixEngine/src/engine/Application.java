package engine;

import org.jsfml.graphics.RenderWindow;
import org.jsfml.graphics.View;
import org.jsfml.system.Vector2f;
import org.jsfml.window.VideoMode;
import org.jsfml.window.WindowStyle;
import org.jsfml.window.event.Event;

public abstract class Application {

    public static RenderWindow window;
    public static boolean autoUpdate = false;

    public static void createWindow(int width, int height, String title) {

        window = new RenderWindow(
                new VideoMode(width, height),
                title, WindowStyle.RESIZE | WindowStyle.DEFAULT
        );
        SceneRenderer.window = window;

    }


    public static Event checkEvents() {
        for (Event event : window.pollEvents()) {
            if (event.type == Event.Type.CLOSED) {
                window.close();
            }
            else {
                if (event.type == Event.Type.RESIZED)  {

                    float w = event.asSizeEvent().size.x;
                    float h = event.asSizeEvent().size.y;
                    window.setView(new View(
                            new Vector2f(
                                    (float) (w / 2.0),
                                    (float) (h / 2.0)
                            ),
                            new Vector2f(w, h)
                    )
            );
                }
                return event;
            }
        }
        return null;
    }


}
