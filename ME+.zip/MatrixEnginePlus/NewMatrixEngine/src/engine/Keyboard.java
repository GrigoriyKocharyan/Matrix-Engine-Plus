package engine;

public class Keyboard {

    public static boolean getPressed(org.jsfml.window.Keyboard.Key key) {
        return org.jsfml.window.Keyboard.isKeyPressed(key);
    }

}
