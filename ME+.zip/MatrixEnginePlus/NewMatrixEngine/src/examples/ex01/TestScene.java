package examples.ex01;

import engine.*;
import org.jsfml.graphics.*;
import org.jsfml.window.event.*;

import java.io.IOException;

public class TestScene extends Scene {

    Texture texture = new Texture(); // создание новой текстуры
    GameObject object; // добавляем игровой объект


    public TestScene(RenderWindow window) throws IOException {
        // получаем изображение из папки с ресурсами
        texture.loadFromFile(Engine.getResource("block.jpg"));
        object = new GameObject(10, 10, texture); // создаём игровой объект
    }

    @Override
    public void onUpdate(RenderWindow window, Event event) {

        if (Keyboard.getPressed(org.jsfml.window.Keyboard.Key.W)) {
            object.positionY -= 0.1f;
        }
        if (Keyboard.getPressed(org.jsfml.window.Keyboard.Key.S)) {
            object.positionY += 0.1f;
        }
        if (Keyboard.getPressed(org.jsfml.window.Keyboard.Key.A)) {
            object.positionX -= 0.1f;
        }
        if (Keyboard.getPressed(org.jsfml.window.Keyboard.Key.D)) {
            object.positionX += 0.1f;
        }

        object.updatePosition(); // обновляем позицию
    }

    @Override
    public void onRender(RenderWindow window, Event event) {
        object.draw(window); // рисуем объект на экране
    }
}
