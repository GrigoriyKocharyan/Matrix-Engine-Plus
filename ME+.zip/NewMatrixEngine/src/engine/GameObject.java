package engine;

import org.jsfml.graphics.Color;
import org.jsfml.graphics.RenderWindow;
import org.jsfml.graphics.Sprite;
import org.jsfml.graphics.Texture;
import org.jsfml.system.Vector2f;

public class GameObject {

    public float positionX, positionY;
    public float scaleX, scaleY;
    public Texture texture;
    public Sprite sprite;

    public GameObject(float _positionX, float _positionY, Texture _texture) {

        positionX = _positionX;
        positionY = _positionY;
        texture = _texture;

        sprite = new Sprite(texture);
        sprite.setColor(new Color(155, 20, 100));
        sprite.setPosition(new Vector2f(positionX, positionY));

    }

    public void draw(RenderWindow window) {
        window.draw(sprite);
    }

    public void update() {
        sprite.setPosition(new Vector2f(positionX, positionY));
        sprite.setScale(new Vector2f(scaleX, scaleY));
        sprite.setTexture(texture);
    }

    public void updatePosition() {
        sprite.setPosition(new Vector2f(positionX, positionY));
    }

    public void updateScale() {
        sprite.setScale(new Vector2f(scaleX, scaleY));
    }

    public void updateTexture() {
        sprite.setTexture(texture);
    }
}
