package engine;

public class Mouse {

    public static int getX() {
        return org.jsfml.window.Mouse.getPosition(SceneRenderer.window).x;
    }

    public static int getY() {
        return org.jsfml.window.Mouse.getPosition(SceneRenderer.window).y;
    }

}
