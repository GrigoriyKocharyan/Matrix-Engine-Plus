package engine;

import org.jsfml.graphics.Color;
import org.jsfml.graphics.RenderWindow;
import org.jsfml.window.event.Event;

public abstract class Scene {

    public boolean isActive = false;
    public Color background = new Color(255, 255, 255);

    public void onUpdate(RenderWindow window, Event event) {

    }

    public void onRender(RenderWindow window, Event event) {

    }

}
