package examples.ex01;

import engine.Scene;
import engine.SceneRenderer;
import engine.Application;
import org.jsfml.window.event.Event;

import java.io.IOException;

public class Main extends Application {

    static Scene testScene; // главная сцена

    public static void main(String[] args) throws IOException {

        createWindow(500, 400, "Hello"); // создание окна
        createScenes(); // создание сцен
        run(); // запуск программы


        while (window.isOpen()) { // главный цикл
            Event event = checkEvents(); // проверяем все события программы
            SceneRenderer.render(event, window); // запускаем отрисовщик сцен
        }
    }

    public static void createScenes() throws IOException {
        testScene = new TestScene(window); // создание экземпляра сцены
        SceneRenderer.addScene(testScene); // добавляем сцену в отрисовщик
    }

    public static void run() {
        testScene.isActive = true; // делаем нашу сцену активно1
    }
}